import numpy as np
import pandas as pd
from keras.models import Sequential
from keras.layers import Dense
from keras.src.layers import LSTM
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.metrics import recall_score, accuracy_score, f1_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from tensorflow.python.keras.callbacks import EarlyStopping

columns = (['duration'
    , 'protocol_type'
    , 'service'
    , 'flag'
    , 'src_bytes'
    , 'dst_bytes'
    , 'land'
    , 'wrong_fragment'
    , 'urgent'
    , 'hot'
    , 'num_failed_logins'
    , 'logged_in'
    , 'num_compromised'
    , 'root_shell'
    , 'su_attempted'
    , 'num_root'
    , 'num_file_creations'
    , 'num_shells'
    , 'num_access_files'
    , 'num_outbound_cmds'
    , 'is_host_login'
    , 'is_guest_login'
    , 'count'
    , 'srv_count'
    , 'serror_rate'
    , 'srv_serror_rate'
    , 'rerror_rate'
    , 'srv_rerror_rate'
    , 'same_srv_rate'
    , 'diff_srv_rate'
    , 'srv_diff_host_rate'
    , 'dst_host_count'
    , 'dst_host_srv_count'
    , 'dst_host_same_srv_rate'
    , 'dst_host_diff_srv_rate'
    , 'dst_host_same_src_port_rate'
    , 'dst_host_srv_diff_host_rate'
    , 'dst_host_serror_rate'
    , 'dst_host_srv_serror_rate'
    , 'dst_host_rerror_rate'
    , 'dst_host_srv_rerror_rate'
    , 'attack'
    , 'level'])

data_train = pd.read_csv('KDDTrain+.csv', header=None, names=columns)
data_test = pd.read_csv('KDDTest+.csv', header=None, names=columns)

attack_n = []
for i in data_train['attack']:
    if i == 'normal':
        attack_n.append(0)
    else:
        attack_n.append(1)

data_train['attack'] = attack_n

attack_n = []
for i in data_test['attack']:
    if i == 'normal':
        attack_n.append(0)
    else:
        attack_n.append(1)

data_test['attack'] = attack_n

clm = ['protocol_type', 'service', 'flag']

onehot_encoder = LabelEncoder()

for x in clm:
    data_train[x] = onehot_encoder.fit_transform(data_train[x])
    data_test[x] = onehot_encoder.fit_transform(data_test[x])

y = data_train['attack'].copy()
x = data_train.drop('attack', axis=1)

x_test_data = data_test.drop('attack', axis=1)
y_test_data = data_test['attack'].copy()

sel = SelectFromModel(RandomForestClassifier(n_estimators=5, random_state=42))
sel.fit(x, y)

selected_features_mask = sel.get_support()
print(selected_features_mask)

x_train_full = x.iloc[:, selected_features_mask]
x_test_full = x_test_data.iloc[:, selected_features_mask]

x_train, x_val, y_train, y_val = train_test_split(x_train_full, y, test_size=0.2, random_state=40)

scaler = StandardScaler()
x_train_scaled = scaler.fit_transform(x_train)
x_val_scaled = scaler.transform(x_val)
x_test_scaled = scaler.transform(x_test_full)

x_train_scaled = np.expand_dims(x_train_scaled, axis=2)
x_val_scaled = np.expand_dims(x_val_scaled, axis=2)
x_test_scaled = np.expand_dims(x_test_scaled, axis=2)

print(x_train_scaled.shape[0], x_train_scaled.shape[1], x_train_scaled.shape[2])


model = Sequential([
    LSTM(64, activation='relu', input_shape=(x_train_scaled.shape[1], x_train_scaled.shape[2])),
    Dense(32, activation='relu'),
    Dense(1, activation='sigmoid')
])

model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

early_stopping = EarlyStopping(
    monitor='val_loss',
    patience=5,
    restore_best_weights=True
)

history = model.fit(x_train_scaled, y_train, epochs=100, batch_size=64, validation_data=(x_val_scaled, y_val),
                    callbacks=[early_stopping])

y_pred_proba = model.predict(x_test_scaled)
y_pred = (y_pred_proba >= 0.5).astype(int)

recall = recall_score(y_test_data, y_pred)

accuracy = accuracy_score(y_test_data, y_pred)
f1 = f1_score(y_test_data, y_pred)

print(f"Recall: {recall}")
print(f"Accuracy: {accuracy}")
print(f'F1-score: {f1}')
